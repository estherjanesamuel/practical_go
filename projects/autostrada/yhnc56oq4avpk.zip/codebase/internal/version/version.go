package version

func Get() string {
	return "0.0.1"
}
